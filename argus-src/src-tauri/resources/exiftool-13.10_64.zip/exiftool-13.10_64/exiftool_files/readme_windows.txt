This readme is for the Windows ExifTool package by Oliver Betz.

This package is intended to avoid problems of the PAR packed original ExifTool for Windows.

It consists of:

* ExifTool by Phil Harvey https://exiftool.org/ resp. https://github.com/exiftool/exiftool
* Strawberry Perl https://strawberryperl.com/
* Tiny launcher by Oliver Betz https://oliverbetz.de/pages/Artikel/ExifTool-for-Windows

See https://exiftool.org/ and https://strawberryperl.com/ for the license of ExifTool and Strawberry Perl.
The launcher is licensed under the https://creativecommons.org/publicdomain/zero/1.0/legalcode CC0 license

I make no warranties about the package, and disclaim liability for all uses of the package, to the fullest extent permitted by applicable law. 

Oliver Betz
